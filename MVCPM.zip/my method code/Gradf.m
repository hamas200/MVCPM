function FG = Gradf(u,L)

FG =L*u;
end

