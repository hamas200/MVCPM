clear all;
k=3;% number of views
cluster=3;
n=150;% number of points
m=1;% run experiment for m times
P(:,:,1)=(1/n)*[16,0,0;0,18,0;0,0,17];   
P(:,:,2)=(1/n)*[16,0.4,0.6;0.4,18,0.55;0.6,0.55,17];
P(:,:,3)=(1/n)*[16,0.8,1.2;0.8,18,1.1;1.2,1.1,17];
P(:,:,4)=(1/n)*[16,1.2,1.8;1.2,18,1.65;1.8,1.65,17]; 
%classify = [333,333,334;333,333,334;333,333,334;333,333,334;333,333,334;...
 %           333,333,334;333,333,334;333,333,334;333,333,334;333,333,334;];
%classify = [200,400,400;250,300,450;300,300,400;300,400,300;400,300,300;...
 %           450,300,250;400,350,250;350,400,250;350,350,400;350,300,350];
%classify = [300,300,400;300,300,400;400,300,300;410,290,300;300,370,330;...
%           300,350,350;280,420,300;300,400,300;450,250,300;450,250,300];
classify = [50,50,50;30,90,30;40,60,50];
%classify = [50,50,50;50,50,50;50,50,50];
%classify = [333,333,334;333,333,334;333,333,334;333,333,334;333,333,334;333,333,334];
%classify = [450,500,550;700,300,500;450,550,500;400,650,450;600,400,500;450,650,400;];
        
        
for y =1:size(P,3)
    for x = 1:m
        sizeA=n;
        AA=cell(1); % record k affinity matrices
        ddxx=cell(1); % record k indicator vectors correspongding to classify
        for j = 1:size(classify,1)
            [AA{j},ddxx{j}]=rand3module(n,classify(j,1),classify(j,2),classify(j,3),P(:,:,y));% generate simulation data
            sizeA_temp = size(AA{j},1);
            sizeA = min(sizeA,sizeA_temp);
        end
        for j = 1:size(classify,1) % transform to the form of N*N*k
            A(:,:,j)=AA{j}(1:sizeA,1:sizeA);
            ddx(:,j)=ddxx{j}(1:sizeA);
        end
        
        [U1]=adaptedweight(A,cluster,1); % proposed method
        dx_total_ = kmeans(U1,cluster,'EmptyAction','drop','Replicates',100);
        num = length(dx_total_)/k;
        for i =1:k
            dx_total(:,i) = dx_total_(1+(i-1)*num:i*num);
        end  
        score_our(x,y) = accuracy(dx_total,ddx,cluster);
        %dx_total_SC_ = kmeans(U2(:,1:cluster),cluster,'EmptyAction','drop','Replicates',100);
        end   
%         profile viewer
        
         
         clear AA;
         clear ddxx;
         clear sizeA;
         clear sizeA_temp;
         clear A;
         clear ddx;
         clear dx;
         clear dx_total;
         clear score_vec;
         clear dx_aasc;
         clear U1;
         clear U2;
         clear dx_total_SC;
    end
    
std_our = std(score_our);
score_our_avg = mean(score_our,1);
% save('score3.mat','score');