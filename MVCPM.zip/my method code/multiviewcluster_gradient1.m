function [U] = multiviewcluster_gradient1(B, idx, cluster)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input: 
%     B: n-by-n PSD matrix; if it is indefinite, first B=B+aI to make it PSD 
%     idx: an integer vector describing the partition
%     cluster: # of the columns of U
%     U: initial guess;
% Output:
%     f: objective value
%     U: the computed solution
%     r_err_f: relative error of the objective value
%     r_err_g: relative error of the gradient
%     iter: # of iterations
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin < 2
    error('Incomplete data input!');
elseif nargin < 3
    k = length(idx);
    for i = 1:k
    [Y,~]= qr(randn(idx(i),cluster),0);
    U(sum(idx(1:i-1))+1:sum(idx(1:i)),:)= Y;
    end
    display('the default (5) # of columns is set.');
elseif nargin < 6
    k = length(idx);
    for i = 1:k
    [Y,~]= qr(randn(idx(i),cluster),0);
    U(sum(idx(1:i-1))+1:sum(idx(1:i)),:)= Y;
    end
end

[U] = pencF(U,B);