clc; clear; close all
warning off;
addpath('./data')
%% load data
[data1,data2,data3]=BRCA;
%% compute distance martix

dist_gene = dist2(data1+1',data1+1');
dist_DNA = dist2(data2',data2');
dist_miRNA = dist2(data3',data3');

%% construct similarity matrix
W_gene = affinityMatrix(dist_gene,20 ,0.25);
W_DNA = affinityMatrix(dist_DNA,20 ,0.25);
W_miRNA = affinityMatrix(dist_miRNA,20 ,0.25);

W_gene_knn = knnAffinity(dist_gene,5,'T');
W_DNA_knn = knnAffinity(dist_DNA,5,'T');
W_miRNA_knn = knnAffinity(dist_miRNA,5,'T');
%% compute indicators
cluster =3;

A(:,:,1)=W_gene;
A(:,:,2)=W_DNA;
A(:,:,3)=W_miRNA;


A_knn(:,:,1)=W_gene_knn;
A_knn(:,:,2)=W_DNA_knn;
A_knn(:,:,3)=W_miRNA_knn;


m=1;% we will run for m times and count the average as the result
num = size(A,1);
score_ = zeros(3,m); % 
score1_ = zeros(3,m);
for K=1:m   

    [U2]=adaptedweight(A_knn,cluster,3); % proposed method
    idx2 = kmeans(U2,cluster,'EmptyAction','drop','Replicates',100);
    xxx=idx2
    

    idx = zeros(num,3);
    for i=1:3
        idx(:,i)=idx2((1+(i-1)*num):i*num);
    end
    [idx1,idx_new,solved] = unification_(idx,U2,cluster,3);
    %idx_mvsc_other = unification(idx_mvsc,cluster);
    %idx_other = unification(idx,cluster);
   
    for i=1:3
        score_(i,K)=silhouette(A(:,:,i),idx(:,i),cluster);
        score1_(i,K) = silhouette(A(solved,solved,i),idx1,cluster);
        score_new_(i,K) = silhouette(A(:,:,i),idx_new,cluster);

    end
end     


score = mean(mean(score_,1));
scoce1 = mean(mean(score1_,1));
score_new = mean(mean(score_new_,1));




        