function [U] = pencF(uin,L)

tstart  = cputime;
[n,p]=size(uin);
% uin represent initial u
u(:,:,1)=uin;

% the first value of beta
beta=0.1*norm(Gradf(u(:,:,1),L),'fro');

% the first value of D
D(:,:,1)=Gradf(u(:,:,1),L)-u(:,:,1)*Ga(Gradf(u(:,:,1),L),u(:,:,1))+beta*u(:,:,1)*(u(:,:,1)'*u(:,:,1)-eye(p,p));

% the first value of eta
eta=1;
% the second value of u
u(:,:,2)=u(:,:,1)-eta*D(:,:,1);

K=1.1*sqrt(p);

% we use this condition to make sure that norm(u(:,:,2),'fro') < K
if norm(u(:,:,2),'fro') > K
    u(:,:,2)=K/norm(u(:,:,2),'fro')*u(:,:,2);
end

% first iteration
i=1;

% we use while to make stop condition

while norm(Gradf(u(:,:,i+1),L)-u(:,:,i+1)*Ga(Gradf(u(:,:,i+1),L),u(:,:,i+1)),'fro') >= 1e-08

   % we use it to calculate the number of iteration
  it(i)=i;

  D(:,:,i+1)=Gradf(u(:,:,i+1),L)-u(:,:,i+1)*Ga(Gradf(u(:,:,i+1),L),u(:,:,i+1))+beta*u(:,:,i+1)*(u(:,:,i+1)'*u(:,:,i+1)-eye(p,p));
  S(:,:,i)=u(:,:,i+1)-u(:,:,i);
  Y(:,:,i)=D(:,:,i+1)-D(:,:,i);
  if mod(i+1,2)== 0
      eta(i+1)=trace(S(:,:,i)'*Y(:,:,i))/trace(Y(:,:,i)'*Y(:,:,i));
      
  elseif mod(i+1,2)== 1
      
      eta(i+1)=trace(S(:,:,i)'*S(:,:,i))/trace(S(:,:,i)'*Y(:,:,i));
  end
%   eta==trace(S'*Y)/trace(Y'*Y)
  u(:,:,i+2)=u(:,:,i+1)-eta(i+1)*D(:,:,i+1);
  
  if norm(u(:,:,i+2),'fro') > K
    u(:,:,i+2)=K/norm(u(:,:,i+2),'fro')*u(:,:,i+2);
  end


i=i+1; 
end
% it=it(length(it));
U=u(:,:,it(length(it)));

% t=1:length(ST);
% plot(t,ST)
% set(gca, 'YScale', 'log')



timetot = cputime - tstart;



end

