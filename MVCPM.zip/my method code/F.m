function FF = F(u,L)

FF=trace(u'*L*u);
end

