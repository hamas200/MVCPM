function D = Ga(GF,u)

D=1/2*(GF'*u+u'*GF);
end

